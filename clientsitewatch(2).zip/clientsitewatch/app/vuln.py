"""
Detection-only checks. Every function here either reads public DNS/HTTP(S)
responses already permitted by the domain's ownership verification, or
queries a public lifecycle-data API (endoflife.date). Nothing here sends a
payload, attempts authentication, or tries to change state on the target.

A finding means "this pattern was observed," never "the system is secure" —
absence of findings just means these specific checks didn't match. See
README.md.
"""
import os, re, socket, ssl
import httpx
from cryptography import x509
from cryptography.hazmat.primitives.asymmetric import ec, rsa

TIMEOUT = 6
MAX_BODY = 4096

# (path, human label, severity). All are plain GET requests to predictable,
# well-known paths — equivalent to a browser loading them.
EXPOSURE_PATHS = [
    ("/.git/HEAD", "Exposed .git repository", "critical"),
    ("/.git/config", "Exposed .git repository", "critical"),
    ("/.env", "Exposed .env file", "critical"),
    ("/.svn/entries", "Exposed .svn repository", "high"),
    ("/backup.sql", "Exposed database backup file", "critical"),
    ("/dump.sql", "Exposed database backup file", "critical"),
    ("/database.sql", "Exposed database backup file", "critical"),
    ("/backup.zip", "Exposed backup archive", "high"),
    ("/wp-config.php.bak", "Exposed WordPress config backup", "critical"),
    ("/config.php.bak", "Exposed config backup", "critical"),
    ("/.htpasswd", "Exposed .htpasswd file", "high"),
    ("/server-status", "Apache server-status exposed", "medium"),
]

# endoflife.date product slug for each software name we can fingerprint.
EOL_SLUG = {"nginx": "nginx", "apache": "apache", "php": "php"}


def _get(ip_, host, path):
    """One plain HTTPS GET, capped read. Raises on any network error."""
    ctx = ssl.create_default_context()
    with socket.create_connection((ip_, 443), timeout=TIMEOUT) as raw, \
         ctx.wrap_socket(raw, server_hostname=host) as s:
        s.settimeout(TIMEOUT)
        s.sendall(f"GET {path} HTTP/1.1\r\nHost: {host}\r\nUser-Agent: ClientSiteWatch\r\nConnection: close\r\n\r\n".encode())
        buf = b""
        while len(buf) < MAX_BODY + 8192:
            d = s.recv(4096)
            if not d:
                break
            buf += d
    head, _, body = buf.partition(b"\r\n\r\n")
    lines = head.decode("latin1", "replace").split("\r\n")
    try:
        status = int(lines[0].split()[1])
    except (IndexError, ValueError):
        status = 0
    headers = {k.strip().lower(): v.strip() for k, v in (l.split(":", 1) for l in lines[1:] if ":" in l)}
    return status, headers, body[:MAX_BODY]


def exposure_checks(ip_, host):
    """GET a random nonexistent path as a 'normal 404' baseline, then compare
    each sensitive path against it. Flags only responses that differ from
    the baseline and don't look like the site's own HTML — this avoids
    false positives on single-page apps that return 200 with the same page
    for every path."""
    try:
        base_status, _, base_body = _get(ip_, host, "/csw-baseline-" + os.urandom(6).hex())
    except Exception as e:
        return {"status": "error", "detail": type(e).__name__, "findings": []}
    findings = []
    for path, label, severity in EXPOSURE_PATHS:
        try:
            status, _, body = _get(ip_, host, path)
        except Exception:
            continue
        if status != 200 or status == base_status:
            continue
        looks_like_normal_page = b"<html" in body.lower() or b"<!doctype" in body.lower()
        if not looks_like_normal_page or body != base_body:
            findings.append({"path": path, "label": label, "severity": severity})
    return {"status": "ok", "findings": findings}


def tls_details(ip_, host):
    """Certificate and cipher quality from the single TLS handshake we make
    anyway. Does not test which protocol versions the server offers — most
    client systems no longer support negotiating TLS 1.0/1.1 at all, so a
    failed downgrade attempt would prove nothing about the server and is
    left out rather than reported as a false pass."""
    out = {}
    try:
        ctx = ssl.create_default_context()
        with socket.create_connection((ip_, 443), timeout=TIMEOUT) as raw, \
             ctx.wrap_socket(raw, server_hostname=host) as s:
            cipher = s.cipher()
            der = s.getpeercert(binary_form=True)
        out["cipher_bits"] = cipher[2] if cipher else None
        cert = x509.load_der_x509_certificate(der)
        out["self_signed"] = cert.issuer == cert.subject
        alg = cert.signature_hash_algorithm
        out["sig_algorithm"] = alg.name if alg else "unknown"
        out["weak_signature"] = out["sig_algorithm"] in ("sha1", "md5")
        pk = cert.public_key()
        if isinstance(pk, rsa.RSAPublicKey):
            out["key_type"], out["key_bits"] = "RSA", pk.key_size
            out["weak_key"] = pk.key_size < 2048
        elif isinstance(pk, ec.EllipticCurvePublicKey):
            out["key_type"], out["key_bits"] = "EC", pk.curve.key_size
            out["weak_key"] = pk.curve.key_size < 224
        else:
            out["key_type"], out["weak_key"] = type(pk).__name__, None
    except Exception as e:
        out["error"] = type(e).__name__
    return out


def hsts_strength(headers):
    v = headers.get("strict-transport-security")
    if not v:
        return "missing"
    m = re.search(r"max-age=(\d+)", v)
    if not m:
        return "present_no_max_age"
    return "present_strong" if int(m.group(1)) >= 15552000 else "present_weak"  # 180 days


def fingerprint(headers, body):
    """Best-effort (name, version) pairs from response headers and, for
    WordPress, a generator meta tag. Returns [] rather than guessing when
    nothing is disclosed — most well-run servers suppress this on purpose,
    which is itself a good sign, not a gap in the scan."""
    found = []
    for raw in (headers.get("server", ""), headers.get("x-powered-by", "")):
        m = re.match(r"([A-Za-z][A-Za-z0-9._-]*)/(\d+\.\d+(?:\.\d+)?)", raw)
        if m:
            found.append((m.group(1).lower(), m.group(2)))
    if body and (b"wp-content" in body or b"wp-includes" in body):
        m = re.search(rb'name="generator"\s+content="WordPress\s+([\d.]+)"', body, re.I)
        found.append(("wordpress", m.group(1).decode() if m else None))
    return found


def eol_lookup(product, version):
    """Looks up whether a disclosed version is past end-of-life via the
    public endoflife.date API. Returns status 'unknown' on any failure or
    unrecognized version — never treated as a pass."""
    slug = EOL_SLUG.get(product)
    if not slug or not version:
        return None
    try:
        r = httpx.get(f"https://endoflife.date/api/v1/products/{slug}/", timeout=8)
        r.raise_for_status()
        releases = r.json()["result"]["releases"]
    except Exception:
        return {"product": product, "version": version, "status": "unknown", "reason": "lookup unavailable"}
    major_minor = ".".join(version.split(".")[:2])
    major = version.split(".")[0]
    for rel in releases:
        if rel.get("name") in (major_minor, major):
            return {"product": product, "version": version, "status": "eol" if rel.get("isEol") else "supported", "eol_from": rel.get("eolFrom")}
    return {"product": product, "version": version, "status": "unknown", "reason": "version not in lifecycle data"}


def run(ip_, host, headers, body):
    """Everything in this module, merged into one result block plus a flat,
    severity-tagged findings list for the UI, the diff, and alert emails."""
    out = {"exposure": exposure_checks(ip_, host), "tls": tls_details(ip_, host), "software": []}
    findings = [dict(f, source="exposed_path") for f in out["exposure"]["findings"]]
    t = out["tls"]
    if t.get("weak_signature"):
        findings.append({"label": f"Certificate uses a weak signature algorithm ({t['sig_algorithm']})", "severity": "high", "source": "tls"})
    if t.get("weak_key"):
        findings.append({"label": f"Certificate key is too small ({t.get('key_bits')}-bit {t.get('key_type')})", "severity": "high", "source": "tls"})
    if t.get("self_signed"):
        findings.append({"label": "Certificate is self-signed", "severity": "medium", "source": "tls"})
    hsts = hsts_strength(headers)
    out["hsts"] = hsts
    if hsts in ("missing", "present_no_max_age", "present_weak"):
        findings.append({"label": {"missing": "No HSTS header", "present_no_max_age": "HSTS header has no max-age", "present_weak": "HSTS max-age is shorter than 180 days"}[hsts], "severity": "low", "source": "tls"})
    for product, version in fingerprint(headers, body):
        eol = eol_lookup(product, version)
        if eol:
            out["software"].append(eol)
            if eol["status"] == "eol":
                findings.append({"label": f"{product} {version} is past end-of-life (EOL {eol.get('eol_from')})", "severity": "high", "source": "software"})
    out["findings"] = findings
    return out
