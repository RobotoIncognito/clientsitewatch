# ClientSiteWatch

FastAPI + SQLite backend, admin page, and static UI (landing, app, admin) served from one process.

## Run
    pip install -r requirements.txt
    export ADMIN_EMAIL=you@example.com ADMIN_PASSWORD='long-random-passphrase' COOKIE_SECURE=0   # COOKIE_SECURE=0 only for local http
    uvicorn app.main:app --port 8000
Open http://localhost:8000 (landing), /app.html (customers), /admin.html (admin).

## Deploy
Build the Dockerfile, mount a volume at /data, copy .env.example to an env file, and put it behind an HTTPS reverse proxy (Caddy or Nginx).
Publish port 8000 only to the proxy: `--forwarded-allow-ips=*` trusts X-Forwarded-For, so direct exposure lets clients spoof IPs and dodge rate limits.
Run one worker only: rate limits and the weekly scheduler are in-process.

## Security built in
scrypt password hashing; random server-side sessions stored hashed (HttpOnly, SameSite=Strict, Secure); CSRF defence via SameSite plus a required X-CSW header on every state-changing call;
login and register rate limits; constant-time-style login path; domain ownership proof (DNS TXT) before any check; SSRF guard (only public IPs are contacted, connections go to the validated IP);
CSP, frame, nosniff and HSTS headers; parameterised SQL; UI built with textContent (no innerHTML); API docs disabled.

## Vulnerability detection layer (app/vuln.py)
Added on verified domains only, as part of the same weekly scan. Everything here is read-only reconnaissance — plain GET
requests to predictable paths and one public lifecycle-data lookup (endoflife.date). Nothing sends a payload, tries to
authenticate, or attempts to change state on the target, so it stays inside vulnerability *scanning*, not exploitation.

- **Exposed files/paths**: checks for a public `.git` repo, `.env`, common backup/config files, and Apache's `server-status`,
  against a random-path baseline so single-page apps that return 200 for everything don't produce false positives.
- **Certificate quality**: weak signature algorithm (SHA-1/MD5), undersized key, self-signed cert, HSTS strength.
- **Software end-of-life**: parses `Server`/`X-Powered-By` headers (and a WordPress generator tag if present) and checks
  the disclosed version against endoflife.date. A lookup failure or unrecognized version is reported as "unknown," never
  as a pass.

**This is still not a penetration test.** It cannot find business-logic flaws, auth-bypass bugs, or anything outside its
fixed check list, and a clean scan is not a claim that the site is secure — the UI and report say so explicitly. Don't
let marketing copy say "we test your site's defenses" or imply a pass/fail security verdict; say what was checked.

## Not included yet
Billing webhook (admin sets plans by hand on /admin.html), PDF reports, email verification, password reset, multi-worker
rate limiting, CVE-level detail (EOL status only, not specific CVEs).
Before charging: write terms and a privacy policy, confirm crt.sh, rdap.org and endoflife.date terms allow commercial
use, and check ODPC registration. The exposed-file checks fetch predictable paths like `/.git/HEAD` and `/.env` on
customer-verified domains only — if you ever let scans run before verification, remove this layer first.
Replace the [placeholders] in web/index.html and point its buttons at your checkout.
